.. Usage chapter frontpage

Usage
=====

This chapter explains how to use Cuckoo.

.. toctree::

    start
    submit
    web
    api
    packages
    results
    utilities
