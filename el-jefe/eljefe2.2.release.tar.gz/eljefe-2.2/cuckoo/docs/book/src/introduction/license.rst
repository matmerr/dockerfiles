=======
License
=======

Cuckoo Sandbox license is shipped with Cuckoo and contained in "LICENSE" file
inside "docs" folder.

==========
Disclaimer
==========

Cuckoo is distributed as it is, in the hope that it will be useful, but without
any warranty neither the implied merchantability or fitness for a particular
purpose.

Whatever you do with this tool is uniquely your own responsibility.

